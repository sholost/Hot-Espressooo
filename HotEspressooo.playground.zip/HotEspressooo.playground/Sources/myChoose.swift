
import Foundation
import UIKit
import PlaygroundSupport

public class MyChoose: UIViewController{
    let thisView = UIView()
    let chooseWelcome = UILabel()
    let btnAmericano = UIButton()
    let btnCappucino = UIButton()
    let btnMocha = UIButton()
    let btnLatte = UIButton()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = myColor().myBackgroundColor
        view.frame = CGRect(x: 0, y: 0, width: 600, height: 800)
        setupView()
        
    }
    
    func setupView(){
        chooseWelcome.text = "Choose how your espresso ☕️ will taste"
        chooseWelcome.font = UIFont.boldSystemFont(ofSize: 25)
        chooseWelcome.frame = CGRect(x:45, y:0, width: 600 - 90, height: 400) //CGRect(x:45, y:20, width: 600, height: 400)
        view.addSubview(chooseWelcome)
        
        btnAmericano.setTitle("Strong", for: .normal)
        btnAmericano.backgroundColor = myColor().chooseButton
        btnAmericano.frame = CGRect(x: 45, y: 300, width: 200, height: 80)
        btnAmericano.titleLabel?.font = UIFont.boldSystemFont(ofSize: 35)
        btnAmericano.layer.cornerRadius = 40.0
        btnAmericano.layer.borderWidth = 3
        btnAmericano.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        btnAmericano.addTarget(self, action: #selector(btnAmericanoPressed), for: .touchUpInside)
        view.addSubview(btnAmericano)
        
        btnLatte.setTitle("Smooth", for: .normal)
        btnLatte.backgroundColor = myColor().chooseButton
        btnLatte.frame = CGRect(x: 45, y: 480, width: 200, height: 80)
        btnLatte.titleLabel?.font = UIFont.boldSystemFont(ofSize: 35)
        btnLatte.layer.cornerRadius = 40.0
        btnLatte.layer.borderWidth = 3
        btnLatte.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        btnLatte.addTarget(self, action: #selector(btnLattePressed), for: .touchUpInside)
        view.addSubview(btnLatte)
        
        btnMocha.setTitle("Sweet and Smooth", for: .normal)
        btnMocha.backgroundColor = myColor().chooseButton
        btnMocha.frame = CGRect(x: 600-250-45, y: 300, width: 250, height: 80)
        btnMocha.titleLabel?.font = UIFont.boldSystemFont(ofSize: 25)
        btnMocha.layer.cornerRadius = 40.0
        btnMocha.layer.borderWidth = 3
        btnMocha.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        btnMocha.addTarget(self, action: #selector(btnMochaPressed), for: .touchUpInside)
        view.addSubview(btnMocha)
        
        btnCappucino.setTitle("Strong and Smooth", for: .normal)
        btnCappucino.backgroundColor = myColor().chooseButton
        btnCappucino.frame = CGRect(x: 600-250-45, y: 480, width: 250, height: 80)
        btnCappucino.titleLabel?.font = UIFont.boldSystemFont(ofSize: 25)
        btnCappucino.layer.cornerRadius = 40.0
        btnCappucino.layer.borderWidth = 3
        btnCappucino.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        btnCappucino.addTarget(self, action: #selector(btnCappucinoPressed), for: .touchUpInside)
        view.addSubview(btnCappucino)
        
        addShadow(btnMocha)
        addShadow(btnLatte)
        addShadow(btnAmericano)
        addShadow(btnCappucino)
        
    }
    func addShadow(_ ingredient: UIButton){
        ingredient.layer.shadowColor = UIColor.black.cgColor
        ingredient.layer.shadowOffset = CGSize(width: 2, height: 2)
        ingredient.layer.shadowOpacity = 1
        ingredient.layer.shadowRadius = 2.0
        ingredient.clipsToBounds = false
    }
    @objc func btnAmericanoPressed(sender: UIButton) {
        view.buttonClicked()
        myNextPage("Americano")
    }
    
    @objc func btnLattePressed(sender:UIButton){
        view.buttonClicked()
        myNextPage("Latte")
    }
    
    @objc func btnMochaPressed(sender:UIButton){
        view.buttonClicked()
        myNextPage("Mocha")
    }
    
    @objc func btnCappucinoPressed(sender:UIButton){
        view.buttonClicked()
        myNextPage("Cappucino")
    }
    
    func myNextPage(_ kopiType : String) {
        
        var kopiPage = UIViewController()
        if kopiType == "Americano"{
            kopiPage = myAmericano()
        } else if kopiType == "Latte"{
            kopiPage = myLatte()
        } else if kopiType == "Mocha"{
            kopiPage = myMocha()
        } else if kopiType == "Cappucino"{
            kopiPage = myCappucino()
        }
        view.removeFromSuperview()
        PlaygroundPage.current.liveView = kopiPage
    }
}
//americano : strong
//smooth : latte
//sweet and smooth : mocca
//smooth and strong : cappucino

