
import UIKit

public class myColor{
    public let myBackgroundColor = #colorLiteral(red: 0.7921568627, green: 0.8156862745, blue: 0.7529411765, alpha: 1.0)
    public let myEspressoCoffeColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
    public let myChocolateColor = #colorLiteral(red: 0.6661406755447388, green: 0.2814039885997772, blue: -0.11574851721525192, alpha: 1.0)
    public let myButtonColor = #colorLiteral(red: 1.0069842338562012, green: 0.6872233152389526, blue: 1.0003864765167236, alpha: 1.0)
    public let chooseButton = #colorLiteral(red: 0.7725490196, green: 0.5803921569, blue: 0.431372549, alpha: 1.0)
    
    public init() {}
}


