import Foundation
import UIKit

public class myFrame{
    public let myTitleFrame : CGRect = CGRect(x:45, y:0, width: 600 - 90, height: 400)
    
    public init(){}
}
