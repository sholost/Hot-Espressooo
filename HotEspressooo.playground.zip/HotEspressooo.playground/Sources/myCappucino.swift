import UIKit
import Foundation
import PlaygroundSupport

public class myCappucino : UIViewController{
    //MARK : My assets
    public let judul = UILabel()
    let details = UILabel()
    let thisView = UIView()
    
    fileprivate var espresso = UIImageView()
    fileprivate var emptyCup = UIImageView()
    fileprivate var steamMilk = UIImageView()
    fileprivate var foam = UIImageView()
    fileprivate var cappucino1 = UIImageView()
    fileprivate var cappucino2 = UIImageView()
    fileprivate var cappucino3 = UIImageView()
    
    let finalView = UIView()
    let burem = UIView()
    let greeting = UILabel()
    let finalCoffee = UIImageView()
    let homeButton = UIButton()
    
    let menu = UIView()
    let espressoLabel = UILabel()
    let milkLabel = UILabel()
    let foamLabel = UILabel()
    
    let espressoCheck = UILabel()
    let waterDone = UILabel()
    let foamDone = UILabel()
    
    let instruksi = UILabel()
    let labelInstruksi = UILabel()
    
    var initEspressoFrame : CGRect = CGRect(x: 35 , y: 30, width: 70, height: 70)
    var initFoamFrame = CGRect(x: 45 , y: 315, width: 60, height: 60)
    var initMilkFrame = CGRect(x: 30 , y: 155, width: 100, height: 100)
    
    var steps : [String] = ["Pour one shot of espresso to the empty cup by dragging it.",
            "Add the steamed milk to the cup in the same amount with espresso.",
            "Drag milk foam to the cup.",
            "Enjoy your drink."]
    
    //var untuk drag2
    var onGoingStep = 0
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = myColor().myBackgroundColor
        view.frame = CGRect(x: 0, y: 0, width: 600, height: 800)
        
        setupView()
    }
    
    func setupView(){
        
        judul.text = "Cappuccino"
        judul.font = UIFont.boldSystemFont(ofSize: 35)
        judul.textColor = UIColor.black
        judul.textAlignment = NSTextAlignment.center
        judul.frame = CGRect(x:45, y:80, width: 600 - 90, height: 35)
        view.addSubview(judul)
        
        details.text = "Cappuccino has this strong taste of coffee yet smooth texture \nbecause of the milk! It combines steamed milk, espresso, \nand foam in the same proportion (1/3, 1/3, 1/3)."
        details.textColor = UIColor.black
        details.textAlignment = NSTextAlignment.center
        details.frame = CGRect(x:45, y:120, width: 600 - 90, height: 75)
        details.lineBreakMode = .byWordWrapping
        details.numberOfLines = 5
        details.layer.cornerRadius = 10
        details.layer.borderWidth = 3
        details.layer.borderColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        view.addSubview(details)
        
        labelInstruksi.text = " 📝 Steps :"
        labelInstruksi.font = labelInstruksi.font.withSize(20)
        labelInstruksi.frame = CGRect(x: 45, y: 217, width: 600 - 45, height: 20)
        //labelInstruksi.textAlignment = NSTextAlignment.center
        view.addSubview(labelInstruksi)
        
        instruksi.text = "Pour one shot espresso to the empty cup."
        instruksi.font = UIFont.boldSystemFont(ofSize: 25)
        instruksi.frame = CGRect(x: 45, y: 227, width: 600 - 45, height: 103)
        instruksi.textAlignment = NSTextAlignment.center
        instruksi.lineBreakMode = .byWordWrapping
        instruksi.numberOfLines = 5
        instruksi.layer.shadowColor = UIColor.yellow.cgColor
        instruksi.layer.shadowOffset = CGSize(width: 2, height: 2)
        instruksi.layer.shadowOpacity = 1
        instruksi.layer.shadowRadius = 2.0
        instruksi.clipsToBounds = false
        view.addSubview(instruksi)
        
        emptyCup.image = UIImage(named: "cup")
        emptyCup.frame = CGRect(x: 250,
                                y: view.frame.size.height/2, width: 300, height: 300)
        emptyCup.contentMode = .scaleAspectFit
        view.addSubview(emptyCup)
        
        cappucino1.image = UIImage(named: "cappucino1Cup")
        cappucino1.frame = CGRect(x: 250,
                                y: view.frame.size.height/2, width: 300, height: 300)
        cappucino1.contentMode = .scaleAspectFit
        cappucino1.isHidden = true
        view.addSubview(cappucino1)
        
        cappucino2.image = UIImage(named: "cappucino2Cup")
        cappucino2.frame = CGRect(x: 250,
                                y: view.frame.size.height/2, width: 300, height: 300)
        cappucino2.contentMode = .scaleAspectFit
        cappucino2.isHidden = true
        view.addSubview(cappucino2)
        
        cappucino3.image = UIImage(named: "cappucinoReady")
        cappucino3.frame = CGRect(x: 250,
                                y: view.frame.size.height/2, width: 300, height: 300)
        cappucino3.contentMode = .scaleAspectFit
        cappucino3.isHidden = true
        view.addSubview(cappucino3)

        
        //MARK : MENU VIEW
        
        view.addSubview(menu)
        menu.layer.borderColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        menu.layer.borderWidth = 3
        menu.layer.cornerRadius = 10
        menu.frame = CGRect(x: 45, y: 330, width: 150, height: 420)
        
        menu.addSubview(espressoLabel)
        espressoLabel.frame = CGRect(x: 0, y: 105, width: 150, height: 15)
        espressoLabel.text = "One shot espresso"
        espressoLabel.font = espressoLabel.font.withSize(13)
        espressoLabel.textAlignment = NSTextAlignment.center
        espressoLabel.textColor = UIColor.black
        
        menu.addSubview(milkLabel)
        milkLabel.frame = CGRect(x: 0, y: 262, width: 150, height: 15)
        milkLabel.text = "Steamed milk"
        milkLabel.font = espressoLabel.font.withSize(13)
        milkLabel.textAlignment = NSTextAlignment.center
        milkLabel.textColor = UIColor.black
        
        menu.addSubview(foamLabel)
        foamLabel.frame = CGRect(x: 0, y: 380, width: 150, height: 15)
        foamLabel.text = "Foamed milk"
        foamLabel.font = espressoLabel.font.withSize(13)
        foamLabel.textAlignment = NSTextAlignment.center
        foamLabel.textColor = UIColor.black
        
        menu.addSubview(espresso)
        espresso.image = UIImage(named: "espressoCup")
        espresso.frame = CGRect(x: 35 , y: 30, width: 70, height: 70)
        addShadow(espresso)
        espresso.contentMode = .scaleAspectFit
        
        menu.addSubview(steamMilk)
        steamMilk.image = UIImage(named: "miruku")
        steamMilk.frame = CGRect(x: 30 , y: 155, width: 100, height: 100)
        steamMilk.contentMode = .scaleAspectFit
        
        menu.addSubview(foam)
        foam.image = UIImage(named: "milkfoam")
        foam.frame = CGRect(x: 45 , y: 315, width: 60, height: 60)
        foam.contentMode = .scaleAspectFit
        
        menu.addSubview(espressoCheck)
        espressoCheck.text = "✅"
        espressoCheck.textAlignment = NSTextAlignment.center
        espressoCheck.font = espressoCheck.font.withSize(35)
        espressoCheck.frame = CGRect(x: 0 , y: 30, width: 150, height: 70)
        espressoCheck.isHidden = true
        
        menu.addSubview(waterDone)
        waterDone.text = "✅"
        waterDone.textAlignment = NSTextAlignment.center
        waterDone.font = espressoCheck.font.withSize(35)
        waterDone.frame = CGRect(x: 0 , y: 155, width: 150, height: 100)
        waterDone.isHidden = true
        
        menu.addSubview(foamDone)
        foamDone.text = "✅"
        foamDone.textAlignment = NSTextAlignment.center
        foamDone.font = espressoCheck.font.withSize(35)
        foamDone.frame = CGRect(x: 0 , y: 315, width: 150, height: 60)
        foamDone.isHidden = true
        
        
        //MARK : final View
        burem.frame = CGRect(x: 0, y: 0, width: 600, height: 800)
        burem.backgroundColor = UIColor.black
        burem.alpha = 0
        view.addSubview(burem)
        
        view.addSubview(finalView)
        finalView.frame = CGRect(x: 0, y: 0, width: 450, height: 550)
        finalView.layer.cornerRadius = 18
        finalView.backgroundColor = myColor().myButtonColor
        finalView.translatesAutoresizingMaskIntoConstraints = false
        finalView.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 0).isActive = true
        finalView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 30).isActive = true
        finalView.alpha = 0
        finalView.widthAnchor.constraint(equalToConstant: 450).isActive = true
        finalView.heightAnchor.constraint(equalToConstant: 550).isActive = true
        
        finalView.addSubview(greeting)
        greeting.text = "Enjoy your cappuccino!"
        greeting.frame = CGRect(x: 0, y: 40, width: 450, height: 40)
        greeting.font = espressoLabel.font.withSize(30)
        greeting.textAlignment = NSTextAlignment.center
        greeting.textColor = UIColor.black
        
        finalView.addSubview(finalCoffee)
        finalCoffee.image = UIImage(named: "cappucinoReady")
        finalCoffee.frame  = CGRect(x: 75, y: 105, width: 300, height: 300)
        
        finalView.addSubview(homeButton)
        homeButton.frame = CGRect(x:100, y:430, width: 250, height: 70)
        homeButton.backgroundColor = myColor().myChocolateColor
        homeButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 35)
        homeButton.layer.cornerRadius = 20.0
        homeButton.layer.borderWidth = 3
        homeButton.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        homeButton.alpha = 0
        homeButton.isHidden = true
        homeButton.setTitle("Try another espresso", for: .normal)
        homeButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        homeButton.titleLabel?.textAlignment = .center
        homeButton.addTarget(self, action: #selector(btnBackHome), for: .touchUpInside)
        
        finalView.isHidden = true
        burem.isHidden = true
    }
    
    @objc func btnBackHome(sender: UIButton) {
        backHome()
    }
    func backHome() {
        view.removeFromSuperview()
        let amer = MyChoose()
        PlaygroundPage.current.liveView = amer
    }
    
    func addShadow(_ ingredient: UIImageView){
        ingredient.layer.shadowColor = UIColor.yellow.cgColor
        ingredient.layer.shadowOffset = CGSize(width: 2, height: 2)
        ingredient.layer.shadowOpacity = 1
        ingredient.layer.shadowRadius = 2.0
        ingredient.clipsToBounds = false
    }
    func changeInstructions(){
        if(onGoingStep == 0) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.instruksi.alpha = 0
            }, completion: nil)
            
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.instruksi.alpha = 1
                self.instruksi.text = self.steps[0]
            }, completion: nil)
        }
        if(onGoingStep == 1) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.instruksi.alpha = 0
            }, completion: nil)
            
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.instruksi.alpha = 1
                self.instruksi.text = self.steps[1]
            }, completion: nil)
        }
        if(onGoingStep == 2) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.instruksi.alpha = 0
            }, completion: nil)
            
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.instruksi.alpha = 1
                self.instruksi.text = self.steps[2]
            }, completion: nil)
        }
        if(onGoingStep == 3) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.instruksi.alpha = 0
            }, completion: nil)
            
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.instruksi.alpha = 1
                self.instruksi.text = self.steps[3]
            }, completion: nil)
            
            setFinalView()
        }
    }
    @objc func checkingForMatch(_ loc : CGPoint, _ onStep : Int) {

        let bahan = loc
        //print("\(onGoingStep)")
        if emptyCup.frame.contains(bahan) && (onGoingStep == 2) {
                //self.putSound()
                foam.isHidden = true
                cappucino3.isHidden = false
                foamDone.isHidden = false
                addShadow(steamMilk)
                onGoingStep = 3
            view.latteArtSound()
                changeInstructions()
        } else {
            foam.frame = initFoamFrame
        }
        if emptyCup.frame.contains(bahan) && (onGoingStep == 1) {
                //self.putSound()
                steamMilk.isHidden = true
                cappucino2.isHidden = false
                waterDone.isHidden = false
                addShadow(foam)
                onGoingStep = 2
                changeInstructions()
            view.pouringWater()
        } else {
            steamMilk.frame = initMilkFrame
        }
        
        if emptyCup.frame.contains(bahan) && (onGoingStep == 0) {
                //self.putSound()
                espresso.isHidden = true
                cappucino1.isHidden = false
            emptyCup.isHidden = true
                espressoCheck.isHidden = false
                addShadow(steamMilk)
                onGoingStep = 1
            view.pouringEspresso()
                changeInstructions()
        } else {
            espresso.frame = initEspressoFrame
        }
        //print("\(bahan), \(emptyCup.frame)")
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: menu)
            if espresso.frame.contains(location) && onGoingStep==0 {
                espresso.center = location
            }
            if steamMilk.frame.contains(location) && onGoingStep==1 {
                steamMilk.center = location
            }
            if foam.frame.contains(location) && onGoingStep==2 {
                foam.center = location
            }
        }
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesMoved(touches, with: event)
        let touch = touches.first!
        let location = touch.location(in: menu)
        if espresso.frame.contains(location) && onGoingStep == 0{
            espresso.center = location
        }
        if steamMilk.frame.contains(location) && onGoingStep==1 {
            steamMilk.center = location
        }
        if foam.frame.contains(location) && onGoingStep==2 {
            foam.center = location
        }
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesMoved(touches, with: event)
        let touch = touches.first!
        let location = touch.location(in: view)
        checkingForMatch(location, onGoingStep)
    }
    
    func setFinalView(){
        UIView.animate(withDuration: 2.0, delay: 1.0) {
            [unowned self] in
               self.finalView.isHidden = false
               self.burem.isHidden = false
               self.burem.alpha = 0.65
               self.finalView.alpha = 1
               //print("lol")
        } completion: { _ in //(Bool) in
            self.view.enjoyYourCappucino()
            self.animateHomeButton()
        }
    }
    
    func animateHomeButton(){
        UIView.animate(withDuration: 2.0, delay: 1.0, options: .transitionCurlUp) {
            self.homeButton.isHidden = false
            self.homeButton.alpha = 1
        }
    }
}

