import Foundation
import UIKit
import PlaygroundSupport

public class ViewController: UIViewController {
  
  var rect: UIView!

    public override func viewDidLoad() {
    super.viewDidLoad()
    
    rect = UIView(frame: CGRect(x: 30, y: 30, width: 50, height: 50))
    rect.backgroundColor = UIColor.orange
    
    self.view.addSubview(rect)
    
    let pan = UIPanGestureRecognizer(target: self, action: Selector(("pan:")))
    rect.addGestureRecognizer(pan)
    
    let touch = UITapGestureRecognizer(target: self, action: Selector(("tap:")))
    touch.numberOfTapsRequired = 2
    rect.addGestureRecognizer(touch)
    
    // Do any additional setup after loading the view, typically from a nib.
  }
  
  func tap(t: UITapGestureRecognizer) {
    print("double tap")
  }
  
  
  func pan(g : UIPanGestureRecognizer) {
    switch g.state {
    case .began:
      print("begin")
    case .ended:
      print("end")
    case .changed:
        self.rect.center = g.location(ofTouch: 0, in: self.view)
    default:
      print("hello")
    }
  }
  


    public override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }


}
