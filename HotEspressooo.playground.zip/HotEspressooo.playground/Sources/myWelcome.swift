
import Foundation
import UIKit
import PlaygroundSupport

public class myWelcome: UIViewController{
    
    //MARK : My Elements
    let helloEspresso = UILabel()
    var welcomeParagraphVar = UILabel()
    let startButton = UIButton()
    
    //MARK : My assets
    fileprivate var imageView = UIImageView()
    fileprivate var imageCloud = UIImageView()
    
    var instructionProcess = 0
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        view.frame = CGRect(x: 0, y: 0, width: 600, height: 800)
        view.backgroundColor = myColor().myBackgroundColor
        view.playBgSound()
        setupView()
    }
    
    func setupView(){
        helloEspresso.text = "Welcome to Hot Espressooo ☕️"
        helloEspresso.font = UIFont.boldSystemFont(ofSize: 35)
        helloEspresso.textColor = UIColor.black
        helloEspresso.frame = CGRect(x:45, y:0, width: 600, height: 400)
        view.addSubview(helloEspresso)
        
        imageView.image = UIImage(named: "solCloudOk.png")
        imageView.frame = CGRect(x: 140, y: -30, width: 200, height: 200)
        imageView.contentMode = .scaleAspectFit
        view.addSubview(imageView)
        
        imageCloud.image = UIImage(named: "solCloudOk.png")
        imageCloud.frame = CGRect(x: 350, y: 30, width: 180, height: 180)
        imageCloud.contentMode = .scaleAspectFit
        view.addSubview(imageCloud)
        
        startButton.setTitle("Start", for: .normal)
        startButton.backgroundColor = myColor().myButtonColor
        startButton.frame = CGRect(x: view.layer.frame.width/2 - 75, y: 500, width: 150, height: 80)
        startButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 35)
        startButton.layer.cornerRadius = 28.0
        startButton.layer.borderColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        startButton.layer.borderWidth = 3
        startButton.addTarget(self, action: #selector(startTapped), for: .touchUpInside)
        startButton.isHidden = true
        addShadow(startButton)
        view.addSubview(startButton)
        
        welcomeParagraphVar = welcomeParagraph()
        welcomeParagraphVar.frame = CGRect(x:45, y:175, width: 600-90, height: 400)
        welcomeParagraphVar.textAlignment = NSTextAlignment.center
        welcomeParagraphVar.lineBreakMode = .byWordWrapping
        welcomeParagraphVar.numberOfLines = 5
        view.addSubview(welcomeParagraphVar)
        
        greetings()
    }
    
    func welcomeParagraph() -> UILabel {
        let welcomePara = UILabel()
        welcomePara.text = "Hello, I'm Sol from Indonesia 🇮🇩."
        welcomePara.font = welcomePara.font.withSize(25)
        welcomePara.textColor = UIColor.black
        return welcomePara
    }
    
    func greetings() {
        if(instructionProcess == 0) {
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.welcomeParagraphVar.alpha = 1
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 1.5, repeats: false, block: { (time) in
                    self.instructionProcess = 1
                    self.greetings()
               })
           }
        }
        if(instructionProcess == 1) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.welcomeParagraphVar.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.welcomeParagraphVar.alpha = 1
                self.welcomeParagraphVar.text = "I love coffee, one of my favorite coffee product is espresso."
                //self.animateIndonesiaOnScreen()
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
                    self.instructionProcess = 2
                    self.greetings()
                    //self.animateIndonesiaOffScreen()
                })
            }
        }
        if(instructionProcess == 2) {
            UIView.animate(withDuration: 1.0, delay: 0, options: .curveEaseOut, animations: {
                self.welcomeParagraphVar.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 1.0, delay: 1.0, options: .curveEaseOut, animations: {
                self.welcomeParagraphVar.alpha = 1
                self.welcomeParagraphVar.text = "Espresso is a concentrated form of coffee created by forcing hot water through super-fine coffee grounds."
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
                    self.instructionProcess = 3
                    self.greetings()
                })
            }
        }
        if(instructionProcess == 3) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.welcomeParagraphVar.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.welcomeParagraphVar.alpha = 1
                self.welcomeParagraphVar.text = "I drink them almost everyday 👀"
                //self.animateIndomieOnScreen()
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 1.5, repeats: false, block: { (time) in
                    self.instructionProcess = 4
                    self.greetings()
                })
            }
        }
        if(instructionProcess == 4) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.welcomeParagraphVar.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.welcomeParagraphVar.alpha = 1
                self.welcomeParagraphVar.text = "I want you to try them too."
                    
                //self.animateIndomieOnScreen()
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 1.5, repeats: false, block: { (time) in
                    self.instructionProcess = 5
                    self.greetings()
                })
            }
        }
        if(instructionProcess == 5) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.welcomeParagraphVar.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.welcomeParagraphVar.alpha = 1
                self.welcomeParagraphVar.text = "Now, you can choose what kind of espresso-based coffee that you want and make it for your own! 🥰 "
            }, completion: { _ in //(Bool) in
                self.startButton.isHidden = false
            })
        }
        
    }
    func addShadow(_ ingredient: UIButton){
        ingredient.layer.shadowColor = UIColor.black.cgColor
        ingredient.layer.shadowOffset = CGSize(width: 2, height: 2)
        ingredient.layer.shadowOpacity = 1
        ingredient.layer.shadowRadius = 2.0
        ingredient.clipsToBounds = false
    }
    @objc func startTapped(sender: UIButton) {
        view.buttonClicked()
        nextPage()
    }
    func nextPage() {
        view.removeFromSuperview()
        let chooseYour = MyChoose()
        PlaygroundPage.current.liveView = chooseYour
    }
}
